import React, { Component } from 'react';
import { connect } from 'react-redux';

class Home extends Component {
    componentDidMount = () => {
        console.log("Props : ", this.props)
    }

    changeHomePageTitleFN = () => {
        this.props.ChangeHomePageTitleRedux("this is title after change");
    }

    changeHomePageDescriptionFN = () => {
        this.props.ChangeHomePageDescriptionRedux("this is description after change");
    }

    render() {
        return (
            <div className="p-3">
                <div>
                    {this.props.homePageTitle}
                    <div className="mt-2">
                        <button type="button" onClick={() => this.changeHomePageTitleFN()} className="btn btn-primary">ChangeTitle</button>
                    </div>
                </div>
                <hr></hr>
                <div>
                    {this.props.homePageDescription}
                    <div className="mt-2">
                        <button type="button" onClick={() => this.changeHomePageDescriptionFN()} className="btn btn-success">ChangeDescription</button>
                    </div>
                </div>
                <div>
                    {this.props.n}
                    <div className="mt-2">
                        <button type="button" onClick={() => this.props.changeNum(90)} className="btn btn-success">ChangeNum</button>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    console.log("mapStateToProps : ", state)
    return {
        homePageTitle: state.homePageTitle,
        homePageDescription: state.homePageDescription,
        n: state.num,
    }
}

const mapDispatchToProps = dispatch => {
    return {
        ChangeHomePageTitleRedux(value) {
            dispatch({
                type: 'changeHomePageTitle',
                payload: value
            })
        },

        ChangeHomePageDescriptionRedux(value) {
            dispatch({
                type: 'changeHomePageDescription',
                payload: value
            })
        },

        changeNum(value) {
            dispatch({
                type: 'changeNUM',
                payload: value
            })
        }
    }
}


export default connect(mapStateToProps, mapDispatchToProps)(Home);