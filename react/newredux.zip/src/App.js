import React from 'react';
import { configureStore } from "@reduxjs/toolkit";
import './App.css';
import { Provider } from 'react-redux';
import reducers from './redux/reducers';
import Home from './pages/Home';

const store = configureStore({ reducer: reducers })

function App() {
  return (
    <Provider store={store}>
      <Home></Home>
    </Provider>
  );
}

export default App;
